import pygame
from settings import *
from debug import debug
from game import Game
import os


class Main():
    def __init__(self):

        pygame.init()
        self.running = True
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        self.width, self.height = pygame.display.get_window_size()
        pygame.display.set_caption("game")
        self.clock = pygame.time.Clock()
        self.game = Game()
        self.fullscreen = False
        self.mouse_locked = False

        self.FPS_list = []
        self.FPS = FPS
        #print("FPS:", self.FPS)

    def run(self):
        self.running = True
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self.mouse_locked = True
                    pygame.mouse.set_visible(False)
                    pygame.event.set_grab(True)
                    self.centre = pygame.display.get_window_size()[0]//2, pygame.display.get_window_size()[1]//2
                    pygame.mouse.set_pos(self.centre)
                    pygame.mouse.get_rel()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                  self.mouse_locked = False
                  pygame.mouse.set_visible(True)
                  pygame.event.set_grab(False)


                if event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                    if self.fullscreen:
                        self.screen = pygame.display.set_mode((self.width, self.height), pygame.RESIZABLE)
                        os.environ['SDL_VIDEO_CENTERED'] = '1'
                    else:
                        os.environ['SDL_VIDEO_CENTERED'] = '1'
                        self.width, self.height = pygame.display.get_window_size()
                        self.screen = pygame.display.set_mode(pygame.display.get_desktop_sizes()[0], pygame.RESIZABLE)
                    self.fullscreen = not self.fullscreen
                    self.game.display = pygame.display.get_surface()

            if self.mouse_locked:
                self.centre = pygame.display.get_window_size()[0]//2, pygame.display.get_window_size()[1]//2
                dx, dy = pygame.mouse.get_rel()
                pygame.mouse.set_pos(self.centre)
            else:
                dx, dy = (0,0)

            self.game.run(dx, dy)
            pygame.display.update()
            #print(self.clock.get_fps())
            self.clock.tick(self.FPS)

            '''
            if self.clock.get_fps() > 30:
                self.FPS_list.append(self.clock.get_fps())
            try:
                print("average FPS:", sum(self.FPS_list) / len(self.FPS_list))
            except:
                pass
            '''



if __name__ == "__main__":
    main = Main()
    main.run()


'''
move onto the actual 3D aspect of the game, use raycasting!!!! YAY!!!! 3D!!!!! YAY!!!!!! WOW!!!!!
WHY IS IT SO SLOW, BE QUICKER PLS
to make it quicker: https://youtu.be/NbSee-XM7WA?t=808
in order to use DDA I need to redo the maze
maybe I could use MY method, because I have all the aura.
javidix9 is useful for this: https://www.youtube.com/channel/UC9yYqQWzLhXj8sKZt2n5wA
fix raycasting dimension, no idea what is happening
'''
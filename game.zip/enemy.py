import pygame
from math import *
from settings import *
from debug import debug

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, obstacle_sprites, player, groups):
        super().__init__(groups)
        self.image = pygame.Surface((1,1))
        self.image.fill("red")
        self.rect = self.image.get_rect(center = (x,y))
        self.x = x
        self.y = y
        self.cords = pygame.math.Vector2(self.x, self.y)
        self.direction = pygame.math.Vector2(0,-1)
        self.speed = 1
        self.player = player
    
    def move(self):
        self.look_at_player()
        self.cords += self.direction * self.speed
        self.rect.center = self.cords
        #print(self.cords, self.rect.center)
    
    def look_at_player(self):
        direction_to_player = self.player.cords - self.cords
        self.direction = direction_to_player.normalize()
    
    def go_into_raycastable_position(self):
        player_dir = self.player.direction.as_polar()[1] #impoemtnme logica
        v_cords_1 = self.cords - self.player.cords
        v_cords_2 = pygame.math.Vector2()
        v_cords_2.x = (v_cords_1.x * cos(player_dir)) - (v_cords_1.y * sin(player_dir))
        v_cords_2.y = (v_cords_1.x * sin(player_dir)) + (v_cords_1.y * cos(player_dir))
        return v_cords_2

    def restrict(self):
        if self.cords.x < 0:
            self.cords.x = 0
        elif self.cords.x > WIDTH - self.rect.width:
            self.cords.x = WIDTH - self.rect.width
        
        if self.cords.y < 0:
            self.cords.y = 0
        elif self.cords.y > HEIGHT - self.rect.height:
            self.cords.y = HEIGHT - self.rect.height
    
    def update(self):
        return None
        self.move()

class SeenEnemy(pygame.sprite.Sprite):
    def __init__(self, enemy, groups):
        super().__init__(groups)
        self.image = pygame.Surface((64,128))
        self.image.fill("red")
        self.rect = self.image.get_rect(center = (0,0))
        self.enemy = enemy
    
    def update(self):
        v_cords = self.enemy.go_into_raycastable_position()
        if v_cords.y < 0:
            self.rect.center = (v_cords.x + (WIDTH//2), HEIGHT//2)
        else:
            self.rect.bottomright = (0,0)
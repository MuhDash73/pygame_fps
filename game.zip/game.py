import pygame
from settings import *
from debug import debug
from player import Player
from enemy import *
from support import *
from tile import Tile
from raycaster import Raycaster

class Game():
    def __init__(self):
        self.surface = pygame.Surface((WIDTH, HEIGHT))
        self.state = "playing"
        
        self.visible_sprites_start = pygame.sprite.Group()

        self.player = Player()
        self.other_updatable_sprites = pygame.sprite.Group()
        self.entity_sprites = pygame.sprite.Group()
        self.visible_sprites_playing = pygame.sprite.Group()
        self.visible_sprites_playing_test = pygame.sprite.Group()
        self.obstacle_sprites = pygame.sprite.Group()
        self.raycastables = []
        self.create_map()

        self.visible_sprites_end = pygame.sprite.Group()
    
    def create_map(self):
        layouts = {
            "map" : import_csv_layout("Assets/map/map.csv")
        }

        for style,layout in layouts.items():
            for row_index,row in enumerate(layout):
                temp_list = []
                for col_index, col in enumerate(row):
                    if col != "-1" or style == "map":
                        x = col_index * TILESIZE
                        y = row_index * TILESIZE
                        if style == "map":
                            if col == "0":
                                self.tile = Tile((x,y),[self.obstacle_sprites, self.visible_sprites_playing_test])
                                self.obstacle_sprites.add(self.tile)
                                temp_list.append(1)
                                print("added tile")
                            elif col == "1":
                                self.player.start(x, y, self.obstacle_sprites, [self.visible_sprites_playing_test])
                                self.raycaster = Raycaster(self.player, self.raycastables)
                                temp_list.append(0)
                                print("added player")
                            elif col == "3":
                                self.latest_enemy = Enemy(x, y, self.obstacle_sprites, self.player, [self.visible_sprites_playing_test, self.other_updatable_sprites, self.entity_sprites])
                                SeenEnemy(self.latest_enemy, [self.visible_sprites_playing, self.other_updatable_sprites])
                                temp_list.append(0)
                            elif col == "-1":
                                temp_list.append(0)
                #print(temp_list)
                self.raycastables.append(temp_list)
        print(self.raycastables)


    def scale(self):
        self.display = pygame.display.get_surface()
        self.scaled_surface = pygame.transform.scale(self.surface, self.display.get_size())
        self.display.blit(self.scaled_surface, (0, 0))

    def run(self, dx, dy):
        self.surface.fill("#000000")
        if self.state == "start_menu":
            pass
        elif self.state == "playing":
            self.player.update(dx, dy)
            self.other_updatable_sprites.update()
            self.raycaster.draw_rays(self.surface)
            self.visible_sprites_playing.draw(self.surface)
            self.raycaster.raycast()
            self.visible_sprites_playing_test.draw(self.surface)

        elif self.state == "end_screen":
            pass

        self.scale()